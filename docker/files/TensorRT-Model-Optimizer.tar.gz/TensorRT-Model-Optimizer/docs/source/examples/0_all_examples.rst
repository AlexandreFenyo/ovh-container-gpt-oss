All GitHub Examples
===================

All examples related to optimization techniques like Quantization (PTQ, QAT), Sparsity, Distillation,
Pruning, TensorRT-LLM deployment and more can be accessed from the ModelOpt GitHub repository at
`github.com/NVIDIA/Model-Optimizer <https://github.com/NVIDIA/Model-Optimizer/>`_.
