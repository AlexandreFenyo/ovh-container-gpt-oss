============
Installation
============


.. toctree::
   :glob:
   :maxdepth: 1

   ./_installation_for_Linux.rst
   ./windows/_installation_for_Windows.rst
