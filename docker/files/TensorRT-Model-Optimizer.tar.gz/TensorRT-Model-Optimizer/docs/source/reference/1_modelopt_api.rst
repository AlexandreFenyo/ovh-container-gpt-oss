============
modelopt API
============

.. Explicitly enumerating all submodules so everything is top-level under the API Reference heading
.. TODO: add future submodules here as well!

.. autosummary::
   :toctree: generated
   :recursive:

   modelopt.deploy
   modelopt.onnx
   modelopt.torch
